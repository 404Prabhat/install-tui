#!/usr/bin/env bash
set -euo pipefail
"$(dirname "$0")/arch-package-tui" "$@"
